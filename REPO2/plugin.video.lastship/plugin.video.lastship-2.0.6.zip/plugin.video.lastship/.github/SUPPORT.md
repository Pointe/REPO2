## Support :

- #### Public [**Gitter**](https://gitter.im/Lastship_Chat/Lobby?utm_source=share-link&utm_medium=link&utm_campaign=share-link) Community
- #### German [Lastship-**Forum**](http://lastship.square7.ch/forum/forumdisplay.php?fid=28)
