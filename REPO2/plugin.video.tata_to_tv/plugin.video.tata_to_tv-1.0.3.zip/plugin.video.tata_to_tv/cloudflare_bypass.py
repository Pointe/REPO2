#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmcaddon,sys,os,urllib,xbmcgui

addon = xbmcaddon.Addon()
addon_path = addon.getAddonInfo('path').decode('utf-8')
sys.path.append(os.path.join(addon_path,'resources','lib'))

from urlparse import urlparse
from resources.lib.parser import cParser
from resources.lib.handler.requestHandler import cRequestHandler

def getUrlDomain(sUrl):
    return urlparse(sUrl)[1]

def _htmlParser(htmlContent,pattern):
    return cParser().parse(htmlContent, pattern)

def _getHtmlContent(sUrl):
    oRequest = cRequestHandler(sUrl)
    oRequest.addHeaderEntry('Host', 'www.tata.to')
    if sUrl == 'https://www.tata.to/channels':
        oRequest.addHeaderEntry('Referer', 'https://tata.to/')
    else:
        oRequest.addHeaderEntry('Referer', 'https://www.tata.to/channels')
    return oRequest