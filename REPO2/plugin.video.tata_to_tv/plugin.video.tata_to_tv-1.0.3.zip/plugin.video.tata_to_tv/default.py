#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc,xbmcgui,xbmcaddon,xbmcplugin,urllib,sys,os,re,cloudflare_bypass

addon = xbmcaddon.Addon()
addon_path = addon.getAddonInfo('path').decode('utf-8')
sys.path.append(os.path.join(addon_path,'resources','lib'))

import html5lib
from bs4 import BeautifulSoup
from resources.lib import common

def open_url(url):
    r = cloudflare_bypass._getHtmlContent(url).request()
    return r

def addDir(name,url,mode,iconimage):
    u=sys.argv[0]+'?url='+str(url)+'&mode='+str(mode)+'&name='+str(name)+'&Image='+str(iconimage)
    liz=xbmcgui.ListItem(name, iconImage='DefaultFolder.png',thumbnailImage=iconimage)
    liz.setInfo( type='Video', infoLabels={ 'Title': name } )
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)

def beautiful_soup_video_data(content):

    soup = BeautifulSoup(content,'html5lib')
    for ml_item in soup.findAll('div',{'class':'ml-item chanel-tem'}):

        if ml_item:
            a = ml_item.find('a')
            if a:
                video_url = a.get('href')
            img = ml_item.find('img')
            if img:
                video_pic = img.get('src')

        if not video_url == None and not img == None :
            addDir(os.path.basename(video_url).upper(),urllib.quote_plus(video_url),0,video_pic)

    xbmc.executebuiltin('Container.SetViewMode(500)')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def regex(content):
    match = re.search(r'<div class="tv-play" data-src="(.+?)"', content)
    if match:
        return match.group(1).replace('embed.html','playlist.m3u8') + '|User-Agent=' + common.FF_USER_AGENT

def play(url, title, pic):
    xlistitem = xbmcgui.ListItem( title, iconImage=pic, thumbnailImage=pic )
    xlistitem.setInfo( "video", { "Title": title } )
    xbmc.Player().play(url,xlistitem)
    sys.exit(0)		

if not sys.argv[2] == '' and 'url=' in sys.argv[2]:
    s_return = str(urllib.unquote(sys.argv[2].split('url=')[1]).decode('utf8'))

    if 'https://www.tata.to/channel/' in s_return:
        stream_url = regex(open_url(s_return))
        play(stream_url,xbmc.getInfoLabel('ListItem.Title'),xbmc.getInfoLabel('ListItem.Icon'))

else:
    beautiful_soup_video_data(open_url('https://www.tata.to/channels'))