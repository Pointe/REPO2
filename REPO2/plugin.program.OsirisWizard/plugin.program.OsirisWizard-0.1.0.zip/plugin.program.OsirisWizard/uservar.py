import os, xbmc, xbmcaddon

#########################################################
### User Edit Variables #################################
#########################################################
ADDON_ID       = xbmcaddon.Addon().getAddonInfo('id')
ADDONTITLE     = 'Osiris Wizard'
EXCLUDES       = [ADDON_ID, 'repository.osiris']
# Text File with build info in it.
BUILDFILE      = 'https://raw.githubusercontent.com/Pointe/WIZARD16-17/master/wizard.txt'
# How often you would list it to check for build updates in days
# 0 being every startup of kodi
UPDATECHECK    = 0
# Text File with apk info in it.  Leave as 'http://' to ignore
APKFILE        = 'http://wolfpackcrew.co.uk/seeddata/wolfpackrepo/wizard/apk.txt'
# Text File with Youtube Videos urls.  Leave as 'http://' to ignore
YOUTUBETITLE   = 'How to guides'
YOUTUBEFILE    = 'https://raw.githubusercontent.com/Pointe/WIZARD16-17/master/TXT/youtube.txt'
# Text File for addon installer.  Leave as 'http://' to ignore
ADDONFILE      = 'https://raw.githubusercontent.com/Pointe/WIZARD16-17/master/TXT/addons.txt'
# Text File for advanced settings.  Leave as 'http://' to ignore http://wolfpackcrew.co.uk/seeddata/wolfpackrepo/wizard/adooninstaller.txt
ADVANCEDFILE   = 'https://raw.githubusercontent.com/Pointe/WIZARD16-17/master/TXT/Advanced.txt'
# Text file for roms and emus
ROMPACK        = 'http://wolfpackcrew.co.uk/seeddata/wolfpackrepo/wizard/rom-packs.txt'
EMUAPKS        = 'http://wolfpackcrew.co.uk/seeddata/wolfpackrepo/wizard/emuapks.txt'

# Dont need to edit just here for icons stored locally
PATH           = xbmcaddon.Addon().getAddonInfo('path')
ART            = os.path.join(PATH, 'resources', 'art')

#########################################################
### THEMING MENU ITEMS ##################################
#########################################################
# If you want to use locally stored icons the place them in the Resources/Art/
# folder of the wizard then use os.path.join(ART, 'imagename.png')
# do not place quotes around os.path.join
# Example:  ICONMAINT     = os.path.join(ART, 'mainticon.png')
#           ICONSETTINGS  = 'http://aftermathwizard.net/repo/wizard/settings.png'
# Leave as http:// for default icon
ICONBUILDS     = os.path.join(ART, 'builds.png')
ICONMAINT      = os.path.join(ART, 'maintenance.png')
ICONSPEED      = os.path.join(ART, 'speedtest.png')
ICONAPK        = os.path.join(ART, 'apk.png')
ICONRETRO      = os.path.join(ART, 'retro.png')
ICONADDONS     = os.path.join(ART, 'addons.png')
ICONYOUTUBE    = os.path.join(ART, 'youtube.png')
ICONSAVE       = os.path.join(ART, 'save.png')
ICONTRAKT      = os.path.join(ART, 'trakt.png')
ICONREAL       = os.path.join(ART, 'real.png')
ICONLOGIN      = os.path.join(ART, 'login.png')
ICONCONTACT    = os.path.join(ART, 'contact.png')
ICONSETTINGS   = os.path.join(ART, 'settings.png')
# Hide the ====== seperators 'Yes' or 'No'
HIDESPACERS    = 'No'
# Character used in seperator
SPACER         = '='

# You can edit these however you want, just make sure that you have a %s in each of the
# THEME's so it grabs the text from the menu item
COLOR1         = 'skyblue'
COLOR2         = 'white'
COLOR3		   = 'orange'
COLOR4		   = 'skyblue'
# Primary menu items   / %s is the menu item and is required
THEME1         = '[COLOR '+COLOR4+'][B][I]([COLOR '+COLOR2+']Osiris[/COLOR])[/B][/COLOR] [COLOR '+COLOR2+']%s[/COLOR][/I]'
# Build Names          / %s is the menu item and is required
THEME2         = '[COLOR '+COLOR2+']%s[/COLOR]'
# Alternate items      / %s is the menu item and is required
THEME3         = '[COLOR '+COLOR4+']%s[/COLOR]'
# Current Build Header / %s is the menu item and is required
THEME4         = '[COLOR '+COLOR4+']Aktuelles Build:[/COLOR] [COLOR '+COLOR2+']%s[/COLOR]'
# Current Theme Header / %s is the menu item and is required
THEME5         = '[COLOR '+COLOR4+']Aktuelles Theme:[/COLOR] [COLOR '+COLOR2+']%s[/COLOR]'
# Alternate items      / %s is the menu item and is required
THEME6         = '[COLOR '+COLOR1+'][B]%s[/B][/COLOR]'

# Message for Contact Page
# Enable 'Contact' menu item 'Yes' hide or 'No' dont hide
HIDECONTACT    = 'No'
# You can add \n to do line breaks
CONTACT        = 'Osiris \nfacebook.com/groups/Osiris/\n\nBloodmoon-IPTV\nfacebook.com/groups/BloodmoonIPTV/'
#Images used for the contact window.  http:// for default icon and fanart
CONTACTICON    = os.path.join(ART, 'icon.png')
CONTACTFANART  = 'http://'
#########################################################

#########################################################
### AUTO UPDATE #########################################
########## FOR THOSE WITH NO REPO #######################
# Enable Auto Update 'Yes' or 'No'
AUTOUPDATE     = 'Yes'
# Url to wizard version
WIZARDFILE     = 'https://raw.githubusercontent.com/Pointe/WIZARD16-17/master/wizard.txt'
#########################################################

#########################################################
### AUTO INSTALL ########################################
########## REPO IF NOT INSTALLED ########################
# Enable Auto Install 'Yes' or 'No'
AUTOINSTALL    = 'Yes'
# Addon ID for the repository
REPOID         = 'repository.Osiris'
# Url to Addons.xml file in your repo folder(this is so we can get the latest version)
REPOADDONXML   = 'http://pointe-projekte.ddns.net/Repo/addon.xml'
# Url to folder zip is located in
REPOZIPURL     = 'http://pointe-projekte.ddns.net/Repo/'
#########################################################

#########################################################
### NOTIFICATION WINDOW##################################
#########################################################
# Enable Notification screen Yes or No
ENABLE         = 'Yes'
# Url to notification file
NOTIFICATION   = 'https://raw.githubusercontent.com/Pointe/WIZARD16-17/master/TXT/Benachrichtigung_Wizard.txt'
# Use either 'Text' or 'Image'
HEADERTYPE     = 'Text'

HEADERMESSAGE  = 'Osiris Wizard'
# url to image if using Image 500x50(Width can vary but height of image needs to be 50px)
HEADERIMAGE    = ''
# Background for Notification Window
BACKGROUND     = ''
#########################################################