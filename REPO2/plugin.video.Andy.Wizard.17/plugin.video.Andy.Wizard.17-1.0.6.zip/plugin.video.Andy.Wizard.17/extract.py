import zipfile

def all(_in, _out, dp=None):
    if dp:
        return allWithProgress(_in, _out, dp)

    return allNoProgress(_in, _out)
        

def all(_in, _out, dp=None):
    if dp:
        return allWithProgress(_in, _out, dp)

    return allNoProgress(_in, _out)

def allWithProgress(_in, _out, dp):

    fh = open(_in, 'rb')
    z = zipfile.ZipFile(fh)
	
    nFiles = float(len(z.infolist()))
    count  = 0

    for name in z.namelist():
        count += 1
        update = count / nFiles * 100
        dp.update(int(update))
        try:
            z.extract(name, _out)
        except:
            pass

    return True